# 新传信号站 · 山海智汇 2026

新闻与传播学科市集：Logo识别、热梗贴纸、扫码新闻编辑台、新传工牌测试。

- `web/`：可直接部署的静态网页、图片、脚本与样式。
- `materials/`：十组Logo题图、十二款贴纸、工牌示例、执行说明和七列表格文案。
- `scripts/`：部署前的本地文件与语法检查。

第三关审核四条模拟稿件，自动计分；第四关按八道情境题生成角色工牌和零食搭配。应用不收集姓名、学号或手机号，没有服务端数据库。成绩与进度保存在参与者浏览器中。

## 本地检查与预览

需要Node.js 22或更新版本。

```sh
npm ci
npm run check
npm run preview
```

## Cloudflare Pages首次部署

采用Wrangler Direct Upload，网站文件夹为`web`，无需构建。

```sh
npx wrangler login
npx wrangler whoami
npx wrangler pages project list
npx wrangler pages project create lzu-media-signal-2026 --production-branch main
npm run deploy
```

若账户已有同名项目，先确认是否为本活动项目；不要覆盖其他网站。名称已被占用时使用另一名称并更新部署命令。实际网址以Cloudflare部署返回结果为准。

## 后续更新

修改文件，运行`npm run check`，提交并推送GitHub，再运行`npm run deploy`。GitHub保存源码；本版采用直接上传，推送GitHub不会自动触发Cloudflare部署。若以后需要自动部署，可另行配置GitHub Actions和受限Cloudflare凭据。

## 二维码与印刷

部署后打开`qr.html`。页面会按当前域名及目录自动生成第三、第四关二维码，可下载SVG或打印页面。不同预览网址会生成不同二维码，正式印刷要使用生产网址。

本仓库不携带旧托管地址的二维码；`materials`中的历史执行说明提到的旧网址属于此前版本，实际参与入口以新生产网址及`qr.html`为准。仓库迁移不会保证微信或特定地区访问成功，需要在活动现场网络及微信中实测。

## 素材与来源

摄影、平台标识、专业资料和评分说明见`web/sources.html`。贴纸生成提示词见`materials/贴纸生成提示词.txt`。第三方图片和标识不随项目代码获得重新授权，保留来源说明。二维码库见`THIRD_PARTY_NOTICES.md`。

Cloudflare官方部署说明：https://developers.cloudflare.com/pages/get-started/direct-upload/
