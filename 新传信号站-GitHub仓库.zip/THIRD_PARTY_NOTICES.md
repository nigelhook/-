# 第三方素材与库

QRCode Generator for JavaScript：Copyright (c) 2009 Kazuhiko Arase，MIT License。
https://github.com/kazuhikoarase/qrcode-generator

库的版权与许可说明保留于web/assets/qrcode-generator.js；完整许可见LICENSES/qrcode-generator-MIT.txt。

其他素材来源与使用范围见web/sources.html。
