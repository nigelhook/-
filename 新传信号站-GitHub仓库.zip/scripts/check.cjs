const fs=require('node:fs');const path=require('node:path');const vm=require('node:vm');
const root=path.join(__dirname,'../web');let count=0;
for(const file of fs.readdirSync(root)){
 if(!file.endsWith('.html'))continue;
 const html=fs.readFileSync(path.join(root,file),'utf8');
 for(const match of html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g)){
  if(match[1].trim())new vm.Script(match[1],{filename:file});
 }
 const markup=html.replace(/<script(?:\s[^>]*)?>[\s\S]*?<\/script>/g,'');
 for(const match of markup.matchAll(/(?:src|href)="([^"#?]+)"/g)){
  const url=match[1];if(/^(?:https?:|data:|mailto:)/.test(url))continue;
  if(!fs.existsSync(path.join(root,url)))throw Error(file+': missing '+url);
 }
 count++;
}
for(const name of ['editor-data.js','logo-data.js'])new vm.Script(fs.readFileSync(path.join(root,name),'utf8'),{filename:name});
console.log('Passed syntax and local asset checks: '+count+' pages');
